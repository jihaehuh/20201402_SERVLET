package example;

public class HelloWorld {
    public String hello() {
        return "NICE! Hello World2";
    }
}
